package MxolisiMaluleka;

//HELLO MY NAME IS MXOLISI MALULEKA, THIS IS THE IMPORTATION PART.

import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;
import java.util.HashMap;
import javax.swing.*;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

//THIS CLASS CONTAINS A HASH MAP THAT HOLDS AND STORES THE USER'S INFORMATION. 
public class Login { 
    static HashMap<String,String> database = new HashMap<>();
    private boolean LOGING_INFORMATION = true;
 
//THIS METHOD CHECKS THE USERNAME.
    public boolean checkingtheusername(String username)throws IllegalArgumentException {
        String regex = "^(?=.*_)[a-zA-Z0-9_]{1,5}$";        
        return username.matches(regex);
    }
  
//THIS METHOD CHECKS THE PASSWORD COMPLEXITY.
    public static boolean checkpasswordcomplexity(String password)throws IllegalArgumentException {
        String regex = "^(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$";
        return Pattern.matches(regex, password);
    }
    
  //THIS METHOD CHECKS THE SOUTH AFRICAN CELLPHONE NUMBER.
    public static boolean checkingtheSAcellnumber(String number){
        String regex ="^\\+27[6-8][0-9]{8}$";
        return Pattern.matches(regex, number);
    }
    
    //THIS METHOD CHECKS AND CAPTURES THE FIRST NAME.
    public String UserRegistration(String username, String password, String number)throws IllegalArgumentException {
        
        if (Registration.firstname.equals("")){  
          String message="Please Enter Your First Name";
          JOptionPane.showMessageDialog(null,message,"ERROR!!!",JOptionPane.ERROR_MESSAGE);
       return message;    
      }else {
        
           String message = "YOUR FIRST NAME IS: " +Registration.firstname;
           JOptionPane.showMessageDialog(null, message);
        }
        
       // THIS METHOD CHECKS AND CAPTURES THE LAST NAME.
        if (Registration.lastname.equals("")){  
          String SAY="Please Enter Your Last Name";
          JOptionPane.showMessageDialog(null, SAY,"ERROR!!!",JOptionPane.ERROR_MESSAGE);
       return SAY;    
      }else {
        
           String SAY = "YOUR LAST NAME IS: " +Registration.lastname;
           JOptionPane.showMessageDialog(null, SAY);
        }
        
    //THIS METHOD CHECKS AND VERIFIES THE USERNAME.
        if (checkingtheusername(username)){
            
            String SAY="USERNAME HAS BEEN SUCCESSFULLY ADDED.";
            JOptionPane.showMessageDialog(null,SAY,"Success!!!",JOptionPane.INFORMATION_MESSAGE );
            
        }else {
            String SAY="INCORRECT USERNAME FORMAT, Please ensure that your username contains an underscore and is no more than five(5) characters.";
            JOptionPane.showMessageDialog(null,SAY,"ERROR!!!",JOptionPane.ERROR_MESSAGE );
            return SAY ;
        }       
     
     // THIS METHOD CHECKS AND VERIFIES THE PASSWORD COMPLEXITY.
        if(!checkpasswordcomplexity(password)){
            
            String SAY  =  "THIS PASSWORD IS INVALID , your Password must contain a Capital Letter, a Special Case, an Underscore, a Number and is atleast EIGHT(8) Characters Long.";
            JOptionPane.showMessageDialog(null, SAY, "Error!!!" ,JOptionPane.ERROR_MESSAGE);
            return SAY;
        }   
        else  { 
            String SAY="PASSWORD HAS BEEN SUCCESSFULLY ADDED.";
            JOptionPane.showMessageDialog(null,SAY,"Success!!!", JOptionPane.INFORMATION_MESSAGE );
        }
        
        // THIS METHOD CHECKS AND VERIFIES THE CELLPHONE NUMBER.
        if (checkingtheSAcellnumber(number)){
         String SAY="YOUR CELLPHONE NUMBER HAS BEEN SUCCESSFULLY ADDED.";
         JOptionPane.showMessageDialog(null,SAY,"Success!!!", JOptionPane.INFORMATION_MESSAGE );
     }
     else {
         String SAY = "INVALID CELLPHONE NUMBER , PLEASE MAKE SURE THIS A SOUTH AFRICAN NUMBER AND STARTS WITH THE SA_INTERNATIONAL CODE(+27) ";
         JOptionPane.showMessageDialog(null, SAY,"Error!!!",JOptionPane.ERROR_MESSAGE);
         return SAY;
     }
    //THIS METHOD RETURNS THE REGISTRATION SUCCESS MESSAGE IF THE USER MEETS THE REQUIREMENTS.
         String success="YOUR ACCOUNT REGISTRATION IS COMPLETE AND SUCCESSFUL , PLEASE LOG IN.";
          JOptionPane.showMessageDialog(null,success,"REGISTRATION SUCCESSFUL",JOptionPane.INFORMATION_MESSAGE);
       return success;       
     }
   
//THIS METHOD CHECKS THE STORED USER'S INFORMATION.
public boolean Logintheuser(String username, String password){
System.out.println( "Loging in :"+ username);
System.out.println( "Password stored :"+ database.get(password));
System.out.println("Your Password is:" + password);
return database.containsKey(username) && database.get(username).equals(password);
}
// THIS METHOD CHECKS AND VERIFIES THE USER'S STORED DETAILS AND RETURNS THE LOGIN STATUS
public String LoginStatusreturner(boolean isSuccess){
String SAY = isSuccess ? 
        "WELCOME BACK " + Registration.firstname + " " + Registration.lastname + " IT IS GREAT TO SEE YOU AGAIN!!! " :
        "INCORRECT USERNAME OR PASSWORD, PLEASE TRY AGAIN."; 
        JOptionPane.showMessageDialog(null, SAY, "INCORRECT USERNAME OR PASSWORD, PLEASE TRY AGAIN.", isSuccess ? JOptionPane.INFORMATION_MESSAGE : JOptionPane.ERROR_MESSAGE);
return SAY;

    }


public class Message  {
    private static int totalMessages = 0;
    private static final ArrayList<String> sentMessages = new ArrayList<>();
    private String messageID;
    private String recipient;
    private String message ;
    
    
    public Message(String messageID, String recipient, String message, String sender, String timestamp) {
        this.messageID = messageID;
        this.recipient = recipient;
        this.message = message;
    }

    Message() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
    public boolean MessageID() {
        return messageID.length() <= 10;
    }
    
    public int checkCell() {
        return (recipient.length() <= 10 && recipient.matches("\\+?[0-9]+")) ? 1 : 0;
    }
    
    public String MessageHash() {
        return messageID.substring(0, 2) + ":" + message.length() + ":" + message.split(" ")[0] + message.split(" ")[message.split(" ").length - 1];
    }
    
    public String sentMessages() {
        
    while (true) { 
        String optionPicker = JOptionPane.showInputDialog(
            null,
            "Welcome to QuickChat\n" +
            "1. Send Messages\n" +
            "2. Show Recently Sent Messages\n" +
            "3. Quit",
            "QuickChat Menu",
            JOptionPane.QUESTION_MESSAGE
        );

        if (optionPicker == null) return "Exit"; 

        switch (optionPicker) {
            case "1": // This will allow user to Send Messages
                try {
                    int messageCount = Integer.parseInt(JOptionPane.showInputDialog(
                        null, "Enter number of messages to send:",JOptionPane.QUESTION_MESSAGE));
                    
                    for (int i = 0; i < messageCount; i++) {
                        
                        String content = JOptionPane.showInputDialog(null, "Enter message content for message " + (i+1) + ":" , JOptionPane.QUESTION_MESSAGE);
                String recipient = JOptionPane.showInputDialog(null, "Enter recipient for message " + (i+1) + ":", JOptionPane.QUESTION_MESSAGE);
                        String sender = "User";
                        String messageID = String.valueOf(System.currentTimeMillis());
                        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());

                        // Create message object
                        Message currentMessage = new Message(messageID,Registration.cellphone, content, sender, timestamp);

                        // This will Handle message disposition
                        String choice = JOptionPane.showInputDialog(null,
                            "Message Options for message " + (i+1) + ":\n" +
                            "0. Send Message\n" +
                            "1. Disregard Message\n" +
                            "2. Store Message", JOptionPane.QUESTION_MESSAGE);

                        switch (choice) {
                            case "0": 
                                String details = "Message Sent Successfully!\n" +
                                    "Message ID: " + currentMessage.messageID + "\n" +
                                    "Message Hash: " + currentMessage.MessageHash() + "\n" +
                                    "RecipientID: " + recipient + "\n" +
                                    "Content: " + currentMessage.message;
                                
                                JOptionPane.showMessageDialog(null, details);
                                sentMessages.add(details);
                                totalMessages++;
                                break;
                            
                            case "1": // 
                                JOptionPane.showMessageDialog(null, "Message disregarded", "Disregard",JOptionPane.INFORMATION_MESSAGE);
                                break;
                            
                            case "2": // This will Store Messages
                                currentMessage.storeMessage();
                                JOptionPane.showMessageDialog(null, "Message stored successfully!", "Store",JOptionPane.INFORMATION_MESSAGE);
                                break;
                            
                            default:
                                JOptionPane.showMessageDialog(null, "Invalid choice - message disregarded","Error",JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Invalid number input!","Error",JOptionPane.ERROR_MESSAGE);
                }
                break;

            case "2": 
                 JOptionPane.showMessageDialog(null, "Coming Soon","Under Construction",JOptionPane.INFORMATION_MESSAGE);
           
                break;

            case "3": // This will close the app
                return "Exit";

            default:
                JOptionPane.showMessageDialog(null, "Invalid option selected!","Error",JOptionPane.ERROR_MESSAGE);
        }
    }
}
    
    public String showMessages() {
        return String.join("\n", sentMessages);
    }
    
    public int returnMessages() {
        return totalMessages;
    }
    
    public void storeMessage() {
        LoginPage messagesArray = new LoginPage();
        LoginPage messageObject = new LoginPage();
        
        messageObject.put("MessageID", messageID);
        messageObject.put("MessageHash", MessageHash());
        messageObject.put("Recipient", recipient);
        messageObject.put("Message", message);
        messagesArray.add(messageObject);
        
        try (FileWriter file = new FileWriter("messages.json")) {
            file.write(messagesArray.toString());
            file.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public String toString() {
        return "Message ID: " + messageID + "\n" +
               "Message Hash: " + MessageHash() + "\n" +
               "Recipient: " + recipient + "\n" +
               "Message: " + message;
    }
    


}

}